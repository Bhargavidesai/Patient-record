from django.contrib import admin
from .models import patient

# Register your models here.
admin.site.register(patient)
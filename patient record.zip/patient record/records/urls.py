from django.urls import path
from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path('table',views.table,name='table'),
    path('deletepatient',views.deletepatient,name='deletepatient'),
    path('edit',views.edit,name='edit'),
    path('editp',views.editp,name='editp'),
    path('new',views.new,name='new'),
    path('newp',views.newp,name='newp')
]
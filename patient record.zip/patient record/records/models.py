from django.db import models

# Create your models here.
from django.utils.timezone import now


class patient(models.Model):
    Firstname=models.CharField(max_length=50,default='')
    Lastname = models.CharField(max_length=50, default='')
    Gender = models.CharField(max_length=10, default='')
    age = models.IntegerField(default=0)
    Disease = models.CharField(max_length=70, default='')
    Doctorname = models.CharField(max_length=50, default='')
    fees = models.IntegerField(default=500)
    date=models.DateTimeField(default=now,blank=True)



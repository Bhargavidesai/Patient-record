from django.shortcuts import render
from django.shortcuts import redirect
from records.models import patient
import pyttsx3

def speak(audio):
    engine = pyttsx3.init('sapi5')
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    engine.say(audio)
    engine.runAndWait()

# Create your views here.
def home(request):
    return render(request, 'home.html')

def table(request):
    obj=patient.objects.all()
    return render(request, 'table.html',{'data':obj})

def deletepatient(request):
    if request.method == 'POST':
        pid=request.POST['p_id']
        obj=patient.objects.get(id=pid)
        obj.delete()
        wish = 'patient record deleted successfully'
        speak(wish)
        return redirect('table')

def edit(request):
    if request.method == 'POST':
        pid = request.POST['p_id']
        obj = patient.objects.get(id=pid)
        return render(request, 'edit.html',{'data': obj})

def editp(request):
    if request.method == 'POST':
        pid = request.POST['p_id']
        fname = request.POST['fname']
        lname = request.POST['lname']
        gender = request.POST['gender']
        age = request.POST['age']
        dis = request.POST['disease']
        dname = request.POST['doctorname']
        fees = request.POST['fees']
        date = request.POST['date']
        obj = patient.objects.get(id=pid)
        obj.Firstname = fname
        obj.Lastname = lname
        obj.Gender = gender
        obj.age = age
        obj.Disease = dis
        obj.Doctorname = dname
        obj.fees = fees
        obj.Date = date
        obj.save()
        wish = 'updation successfull'
        speak(wish)
        return redirect('table')

def new(request):
    return render(request,'new.html')

def newp(request):
    if request.method == 'POST':
        fname = request.POST['fname']
        lname = request.POST['lname']
        gender = request.POST['gender']
        age = request.POST['age']
        dis = request.POST['disease']
        dname = request.POST['doctorname']
        fees = request.POST['fees']
        date = request.POST['date']
        obj=patient(Firstname=fname,Lastname=lname,Gender=gender,age=age,Disease=dis,Doctorname=dname,fees=fees,date=date)
        obj.save()
        wish = 'Patient  added '
        speak(wish)
        return redirect('table')

